<?php

return [
    'Names' => [
        'GHS' => [
            0 => 'GH₵',
            1 => 'GHS',
        ],
    ],
];
