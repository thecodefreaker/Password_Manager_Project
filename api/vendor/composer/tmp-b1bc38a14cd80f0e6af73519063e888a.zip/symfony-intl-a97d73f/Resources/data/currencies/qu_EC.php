<?php

return [
    'Names' => [
        'PEN' => [
            0 => 'PEN',
            1 => 'Sol Peruano',
        ],
        'USD' => [
            0 => '$',
            1 => 'Dólar Americano',
        ],
    ],
];
