<?php

return [
    'Names' => [
        'TTD' => [
            0 => '$',
            1 => 'Trinidad & Tobago Dollar',
        ],
    ],
];
