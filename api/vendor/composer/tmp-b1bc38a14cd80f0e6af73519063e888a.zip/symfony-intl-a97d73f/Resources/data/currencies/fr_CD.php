<?php

return [
    'Names' => [
        'CDF' => [
            0 => 'FC',
            1 => 'franc congolais',
        ],
    ],
];
