<?php

return [
    'Names' => [
        'USD' => [
            0 => '$',
            1 => 'dólar estadounidense',
        ],
    ],
];
