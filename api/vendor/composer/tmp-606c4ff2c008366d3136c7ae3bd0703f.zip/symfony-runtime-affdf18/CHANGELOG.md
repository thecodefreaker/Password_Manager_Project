CHANGELOG
=========

5.3.0
-----

 * Add the component
