CHANGELOG
=========

4.4.0
-----

 * implement PSR-13 directly

3.3.0
-----

 * added the component
